package jiraiyah.allthatmatters.gui;

import jiraiyah.allthatmatters.ModReference;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.client.gui.screen.ingame.HandledScreens;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.screen.ScreenHandlerType;

public class ModScreenHandlers
{
    //public static ScreenHandlerType SAMPLE_SCREEN_HANDLER;

    /*public static final ScreenHandlerType<InfusingStationScreenHandler> INFUSING_POLISHING_SCREEN_HANDLER =
            Registry.register(Registries.SCREEN_HANDLER, AllThatMatters.identifier("infusing_station"),
                    new ExtendedScreenHandlerType<>(InfusingStationScreenHandler::new));*/

    public static void register()
    {
        ModReference.LOGGER.info(">>> Registering Screen Handlers");

        /*SAMPLE_SCREEN_HANDLER = ScreenHandlerRegistry.registerExtended("sample_screen",
                (syncId, inventory, buf) -> new SampleHandler(syncId, inventory, ScreenHandlerContext.create(inventory.player.getWorld(), buf.readBlockPos())));*/

        //HandledScreens.register(ModScreenHandlers.INFUSING_POLISHING_SCREEN_HANDLER, InfusingStationScreen::new);
    }
}