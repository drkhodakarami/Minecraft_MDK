package jiraiyah.allthatmatters.gui.screen;

import io.github.cottonmc.cotton.gui.client.CottonInventoryScreen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

//public class SampleScreen extends CottonInventoryScreen<ChunkLoaderScreenHandler>
public class SampleScreen
{
    /*public ChunkLoaderScreen(ChunkLoaderScreenHandler container, PlayerEntity player, Text title)
    {
        super(container, player, title);
    }*/
}