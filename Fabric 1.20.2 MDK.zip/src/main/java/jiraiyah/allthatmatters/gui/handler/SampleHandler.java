package jiraiyah.allthatmatters.gui.handler;

import io.github.cottonmc.cotton.gui.SyncedGuiDescription;
import io.github.cottonmc.cotton.gui.widget.WButton;
import io.github.cottonmc.cotton.gui.widget.WLabel;
import io.github.cottonmc.cotton.gui.widget.WPlainPanel;
import io.github.cottonmc.cotton.gui.widget.WToggleButton;
import io.github.cottonmc.cotton.gui.widget.data.HorizontalAlignment;
import io.github.cottonmc.cotton.gui.widget.data.Insets;
import io.github.cottonmc.cotton.gui.widget.data.VerticalAlignment;
import jiraiyah.allthatmatters.ModReference;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.text.Text;

public class SampleHandler extends SyncedGuiDescription
{
    BlockEntity loaderEntity;
    WToggleButton[][] buttonsMatrix;
    ScreenHandlerContext context;

    //public SampleHandler(int syncId, PlayerInventory playerInventory)
    public SampleHandler(ScreenHandlerType<?> type, int syncId, PlayerInventory playerInventory)
    {
        super(type, syncId, playerInventory);

        this.context = context;
        context.run((world, pos) -> loaderEntity = world.getBlockEntity(pos));

        WPlainPanel root = new WPlainPanel();
        root.setSize(128, 140);
        root.setInsets(Insets.ROOT_PANEL);
        setRootPanel(root);

        WButton selectAll = new WButton(Text.of("All"));
        selectAll.setOnClick(() ->
        {

        });

        root.add(selectAll, 16, 128, 40, 24);

        WLabel north = new WLabel(Text.of("N"));
        north.setHorizontalAlignment(HorizontalAlignment.CENTER);
        north.setVerticalAlignment(VerticalAlignment.CENTER);
        root.add(north, 54, 2, 16, 16);

        buttonsMatrix = new WToggleButton[5][7];
        for (int i = 0; i < 5; i++)
        {
            int posX = (19 * i + 16);
            for (int j = 0; j < 7; j++)
            {
                WToggleButton curr = new WToggleButton(ModReference.identifier("textures/gui/loaded.png"), ModReference.identifier("textures/gui/not_loaded.png"));
                curr.setOnToggle((on) ->
                {

                });
                int posY = 19 * j + 16;
                root.add(curr, posX, posY, 16, 16);
                buttonsMatrix[i][j] = curr;
            }
        }
    }
}