package jiraiyah.allthatmatters.command;

import jiraiyah.allthatmatters.ModMain;
import jiraiyah.allthatmatters.ModReference;

public class ModCommands
{
    public static void register()
    {
        ModReference.LOGGER.info(">>> Registering Commands");
    }
}