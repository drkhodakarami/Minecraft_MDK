package jiraiyah.allthatmatters.recipe;//package jiraiyah.stripblock.recipe;

//import jiraiyah.stripblock.StripBlock;
//import net.minecraft.registry.Registries;
//import net.minecraft.registry.Registry;
//import net.minecraft.util.Identifier;

import jiraiyah.allthatmatters.ModReference;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.RecipeType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModRecipes
{
    //public static final RecipeType<InfusingStationCraftingRecipe> INFUSING_STATION_TYPE = new RecipeType<>(){};
    //public static final RecipeSerializer<InfusingStationCraftingRecipe> INFUSING_STATION_SERIALIZER = new InfusingStationCraftingRecipe.Serializer();

    private ModRecipes()
    {
        throw new AssertionError();
    }

    public static void register()
    {
        ModReference.LOGGER.info(">>> Registering Recipes for : " + ModReference.ModID);

        //register("advance_infusing", INFUSING_STATION_TYPE);
        //register("advance_infusing", INFUSING_STATION_SERIALIZER);
    }

    private static void register(String name, RecipeSerializer<?> serializer)
    {
        Registry.register(Registries.RECIPE_SERIALIZER, ModReference.identifier(name), serializer);
    }

    private static void register(String name, RecipeType<?> serializer)
    {
        Registry.register(Registries.RECIPE_TYPE, ModReference.identifier(name), serializer);
    }
}