package jiraiyah.allthatmatters.datagen.world;

public class ModTreeGeneration
{
    public static void generateTrees()
    {
        //BiomeModifications.addFeature(BiomeSelectors.foundInOverworld());
        /*BiomeModifications.addFeature(BiomeSelectors.includeByKey(BiomeKeys.PLAINS, BiomeKeys.FOREST),
                GenerationStep.Feature.VEGETAL_DECORATION, ModPlacedFeatures.RED_MAPLE_PLACED_KEY);*/
    }
}