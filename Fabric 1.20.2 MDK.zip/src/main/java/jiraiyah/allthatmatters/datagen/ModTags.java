package jiraiyah.allthatmatters.datagen;

import jiraiyah.allthatmatters.ModReference;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

public class ModTags
{
    public static class Blocks
    {
        //public static final TagKey<Block> GEM_BLOCKS = createCommonTag("gem_blocks");

        private static TagKey<Block> createTag(String name)
        {
            return TagKey.of(RegistryKeys.BLOCK, ModReference.identifier(name));
        }

        private static TagKey<Block> createCommonTag(String name)
        {
            return TagKey.of(RegistryKeys.BLOCK, new Identifier("c", name));
        }
    }

    public static class Items
    {
        //public static final TagKey<Item> CASTS = createCommonTag("casts");

        private static TagKey<Item> createTag(String name)
        {
            return TagKey.of(RegistryKeys.ITEM, ModReference.identifier(name));
        }

        private static TagKey<Item> createCommonTag(String name)
        {
            return TagKey.of(RegistryKeys.ITEM, new Identifier("c", name));
        }
    }
}