package jiraiyah.allthatmatters.block;//package jiraiyah.stripblock.block.entity;

import jiraiyah.allthatmatters.ModMain;

public class ModBlockEntities
{
    /*public static final BlockEntityType<StripperBlockEntity> STRIPPER_BLOCK_ENTITY =
            Registry.register(Registries.BLOCK_ENTITY_TYPE, new Identifier(StripBlock.ModID, "stripper_be"),
                    FabricBlockEntityTypeBuilder.create(StripperBlockEntity::new, ModBlocks.STRIPPER_BLOCK).build());*/

    public static void register()
    {
        ModMain.LOGGER.info(">>> Registering Block Entities");
    }
}