package jiraiyah.allthatmatters;

import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ModReference
{
    public static final String ModID = "modid";
    public static final Logger LOGGER = LoggerFactory.getLogger(ModID);

    @NotNull
    public static Identifier identifier(@NotNull String path)
    {
        return new Identifier(ModID, path);
    }
}