package jiraiyah.allthatmatters.item;//package jiraiyah.stripblock.item;

import jiraiyah.allthatmatters.ModReference;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModItems
{
    //public static final Item HEAD_NETHERITE_AXE = registerItem("head_netherite_axe", new Item(new FabricItemSettings()));

    /*public static final Item TOOL_COPPER_AXE = registerItem("tool_copper_axe",
            new AxeItem(ModToolMaterial.COPPER, 3, 1, new FabricItemSettings()));
    public static final Item TOOL_COPPER_HOE = registerItem("tool_copper_hoe",
            new HoeItem(ModToolMaterial.COPPER, 0, 0, new FabricItemSettings()));
    public static final Item TOOL_COPPER_PICKAXE = registerItem("tool_copper_pickaxe",
            new PickaxeItem(ModToolMaterial.COPPER, 1, 1f, new FabricItemSettings()));
    public static final Item TOOL_COPPER_SHOVEL = registerItem("tool_copper_shovel",
            new ShovelItem(ModToolMaterial.COPPER, 0, 0, new FabricItemSettings()));
    public static final Item TOOL_COPPER_SWORD = registerItem("tool_copper_sword",
            new SwordItem(ModToolMaterial.COPPER, 5, 3, new FabricItemSettings()));*/

    /*public static final Item ARMOR_AMETHYST_HELMET = registerItem("armor_amethyst_helmet",
            new ModArmorItem(ModArmorMaterial.AMETHYST, ArmorItem.Type.HELMET, new FabricItemSettings()));
    public static final Item ARMOR_AMETHYST_CHESTPLATE = registerItem("armor_amethyst_chestplate",
            new ArmorItem(ModArmorMaterial.AMETHYST, ArmorItem.Type.CHESTPLATE, new FabricItemSettings()));
    public static final Item ARMOR_AMETHYST_LEGGINGS = registerItem("armor_amethyst_leggings",
            new ArmorItem(ModArmorMaterial.AMETHYST, ArmorItem.Type.LEGGINGS, new FabricItemSettings()));
    public static final Item ARMOR_AMETHYST_BOOTS = registerItem("armor_amethyst_boots",
            new ArmorItem(ModArmorMaterial.AMETHYST, ArmorItem.Type.BOOTS, new FabricItemSettings()));*/

    private ModItems()
    {
        throw new AssertionError();
    }

    private static Item registerItem(String name, Item item)
    {
        return Registry.register(Registries.ITEM, ModReference.identifier(name), item);
    }

    public static void register()
    {
        ModReference.LOGGER.info(">>> Registering Items");
    }
}