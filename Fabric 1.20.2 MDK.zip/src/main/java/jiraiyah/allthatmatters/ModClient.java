package jiraiyah.allthatmatters;

import jiraiyah.allthatmatters.block.ModBlockEntities;
import jiraiyah.allthatmatters.datagen.ModModelPredicateProvider;
import jiraiyah.allthatmatters.fluid.ModFluids;
import jiraiyah.allthatmatters.networking.ModMessages;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screen.ingame.HandledScreens;

public class ModClient implements ClientModInitializer
{
    @Override
    public void onInitializeClient()
    {
        ModMessages.registerS2CPackets();
        //        //HandledScreens.register(ModScreenHandlers.INFUSING_POLISHING_SCREEN_HANDLER, InfusingStationScreen::new);

        //BlockEntityRendererFactories.register(ModBlockEntities.INFUSING_STATION_BLOCK_ENTITY, InfusingStationBlockEntityRenderer::new);

        /*//region Fluid Handling
        FluidRenderHandlerRegistry.INSTANCE.register(ModFluids.STILL_MOLTEN_ENDERITE, ModFluids.FLOWING_MOLTEN_ENDERITE,
                new SimpleFluidRenderHandler(
                        AllThatMatters.identifier("block/liquid"),
                        AllThatMatters.identifier("block/liquid_flow"),
                        0xA10C5E7C));
        BlockRenderLayerMap.INSTANCE.putFluids(RenderLayer.getTranslucent(),
                ModFluids.STILL_MOLTEN_ENDERITE, ModFluids.FLOWING_MOLTEN_ENDERITE);
        //endregion*/

        // Lib GUI
        /*HandledScreens.<ChunkLoaderScreenHandler, ChunkLoaderScreen>register(ModScreenHandlers.CHUNK_LOADER_SCREEN_HANDLER, (gui, inventory, title) -> new ChunkLoaderScreen(gui, inventory.player, title));*/

        ModModelPredicateProvider.registerModels();
    }
}