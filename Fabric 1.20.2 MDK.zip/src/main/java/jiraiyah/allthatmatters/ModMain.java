package jiraiyah.allthatmatters;

import jiraiyah.allthatmatters.block.ModBlockEntities;
import jiraiyah.allthatmatters.block.ModBlocks;
import jiraiyah.allthatmatters.command.ModCommands;
import jiraiyah.allthatmatters.datagen.world.ModWorldGeneration;
import jiraiyah.allthatmatters.fluid.ModFluids;
import jiraiyah.allthatmatters.gui.ModScreenHandlers;
import jiraiyah.allthatmatters.item.ModItemGroups;
import jiraiyah.allthatmatters.item.ModItems;
import jiraiyah.allthatmatters.networking.ModMessages;
import jiraiyah.allthatmatters.recipe.ModRecipes;
import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ModMain implements ModInitializer
{
    @Override
    public void onInitialize()
    {
        ModReference.LOGGER.info(">>> Initializing");

		/*ServerWorldEvents.LOAD.register((world, entity) ->
        {
            var server = world.getOverworld().getServer();
            ModStatsHandler stats = ModStatsHandler.getServerState(server);
            if (!stats.getWorldCreate())
                stats.setWorldCreated(true);
        });*/

        ModItems.register();
        ModBlocks.register();
        ModItemGroups.register();
        ModCommands.register();
        ModBlockEntities.register();
        ModScreenHandlers.register();
        ModRecipes.register();
        ModWorldGeneration.generateModWorldGen();
        ModMessages.registerC2SPackets();

        ModFluids.register();
    }
}